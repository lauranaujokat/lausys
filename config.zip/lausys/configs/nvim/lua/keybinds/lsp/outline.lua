local map = vim.keymap.set
map("n", "<leader>o", "<cmd>Outline<cr>")
