local map = vim.keymap.set
map("n", "<C-n>", "<cmd>Neotree toggle reveal_force_cwd<cr>")
