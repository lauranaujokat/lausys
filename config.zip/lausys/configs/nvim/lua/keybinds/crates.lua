local map = vim.keymap.set
map("n", "<leader>cp", "<cmd>Crates show_popup<cr>")
map("n", "<leader>cf", "<cmd>Crates show_features_popup<cr>")
map("n", "<leader>cr", "<cmd>Crates open_repository<cr>")
map("n", "<leader>cd", "<cmd>Crates open_documentation<cr>")
