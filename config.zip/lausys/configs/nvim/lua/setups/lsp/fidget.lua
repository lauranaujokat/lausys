require("fidget").setup({
	notification = {
		window = {
			winblend = 0,
			border = "rounded",
		}
	}
})
