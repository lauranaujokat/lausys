require("startup").setup({theme = "dashboard"}) -- put theme name here
